export const maxTime: number
export const minTime: number
