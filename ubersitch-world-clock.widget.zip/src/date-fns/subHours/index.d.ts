// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { subHours } from 'date-fns'
export default subHours
