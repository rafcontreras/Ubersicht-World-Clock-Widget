// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { format } from 'date-fns'
export default format
